import { type NextRequest, NextResponse } from "next/server"
import { streamText } from "ai"
import { sql } from "drizzle" // Import the sql tagged template literal

export const runtime = "edge"

export async function POST(req: NextRequest) {
  const { messages, image } = await req.json()

  let updatedMessages = messages

  if (image) {
    const lastMessage = messages[messages.length - 1]
    updatedMessages = [
      ...messages.slice(0, -1),
      {
        ...lastMessage,
        content: [
          { type: "text", text: lastMessage.content },
          { type: "image_url", image_url: { url: `data:image/jpeg;base64,${image}` } },
        ],
      },
    ]
  }

  // Log the conversation to the database
  await sql`
    INSERT INTO conversations (user_message, ai_message)
    VALUES (${updatedMessages[updatedMessages.length - 1].content}, '')
  `

  const result = streamText({
    model: "emilio-e01",
    messages: updatedMessages,
    api_key: process.env.API_KEY,
  })

  return result.toDataStreamResponse()
}

